import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/context/ThemeContext";


const geistSans = Geist({
  variable:"--font-geist-sans",
  subsets:["latin"],
});


const geistMono = Geist_Mono({
  variable:"--font-geist-mono",
  subsets:["latin"],
});


export const metadata: Metadata = {
 title:"Smart Mosque",
 description:"Modern Mosque Management System",
};


export default function RootLayout({
 children,
}:{
 children:React.ReactNode;
}){


return (

<html
lang="en"
className={`${geistSans.variable} ${geistMono.variable}`}
>

<body
className="
min-h-screen
antialiased
"
>

<ThemeProvider>

{children}

</ThemeProvider>


</body>

</html>

)

}
